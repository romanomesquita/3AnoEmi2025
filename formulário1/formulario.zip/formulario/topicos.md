# Formulário

- Criar servidor no discord

- Explicar sobre webhooks

- Mostrar modelo de código pro Discord
discohook.org

- Criar o código